#!/usr/bin/env python

import sys
import time
import numpy as np
from trafficlib import initroad, updatebcs, updateroad

def main(argv):

  # Simulation parameters
  NCELL = 100000
  maxiter = 200000000/NCELL
  printfreq = maxiter/10

  newroad  = np.zeros(NCELL+2)
  oldroad  = np.zeros(NCELL+2)

  density = 0.52

  sys.stdout.write('Length of road is {0}\n'.format(NCELL))
  sys.stdout.write('Number of iterations is {0}\n'.format(maxiter))
  sys.stdout.write('Target density of cars is {0}\n'.format(density))

  # Initialise road accordingly using random number generator
  sys.stdout.write('Initialising ...\n')

  ncars = initroad(oldroad, density)

  sys.stdout.write('... done\n')

  sys.stdout.write('Actual Density of cars is {0}\n\n'.format(float(ncars)/float(NCELL)))

  for iter in range(1, maxiter+1):

     updatebcs(oldroad)

     nmove = updateroad(newroad, oldroad)
     
     print (newroad[1:20], end="\r")

     # Copy new to old array
     oldroad[1:NCELL] = newroad[1:NCELL]

     if iter % printfreq == 0:

        sys.stdout.write('At iteration {0} average velocity is {1}\n'
                         .format(iter, float(nmove)/float(ncars)))
        
      


  sys.stdout.write('\nFinished\n\n')

if __name__ == "__main__":
        main(sys.argv[1:])
