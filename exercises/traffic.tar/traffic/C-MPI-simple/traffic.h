#define SEED  5743

int initroad(int *road, int n, float density, int seed);
int updateroad(int *newroad, int *oldroad, int n);
